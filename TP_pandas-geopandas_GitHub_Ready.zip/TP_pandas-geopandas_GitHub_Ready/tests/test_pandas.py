
# ======================================================================================
# TESTS UNITAIRES – PANDAS 
# ======================================================================================

from pathlib import Path
import pandas as pd  # type: ignore

# --- RENDU: import des fonctions métier (PAS depuis un test)
from tp2_application_geo_g37 import load_villes_csv, clean_villes_df, stats_population


# --- RENDU: chemins projet (racine) + data/villes.csv
BASE_DIR = Path(__file__).resolve().parent
CSV_PATH = BASE_DIR / "data" / "villes.csv"


def test_4a_load_villes_csv_ok_and_has_min_columns():
    # --- RENDU: le fichier existe
    assert CSV_PATH.exists(), f"CSV introuvable : {CSV_PATH}"

    # --- RENDU: chargement OK
    df = load_villes_csv(CSV_PATH)
    assert isinstance(df, pd.DataFrame)
    assert len(df) > 0

    # --- RENDU: colonnes minimales
    required = {"ville", "pays", "population", "latitude", "longitude"}
    assert required.issubset(df.columns)


def test_4a_clean_villes_df_rules_respected_and_adds_id_ligne():
    # --- RENDU: chargement
    df = load_villes_csv(CSV_PATH)

    # --- RENDU: nettoyage
    df_clean = clean_villes_df(df)

    # --- RENDU: contraintes nettoyage
    assert len(df_clean) > 0
    assert "id_ligne" in df_clean.columns
    assert df_clean[["population", "latitude", "longitude"]].isna().sum().sum() == 0
    assert (df_clean["population"] > 0).all()
    assert df_clean["latitude"].between(-90, 90).all()
    assert df_clean["longitude"].between(-180, 180).all()

    # --- RENDU: id_ligne 1..n
    assert int(df_clean["id_ligne"].iloc[0]) == 1
    assert df_clean["id_ligne"].is_monotonic_increasing
    assert int(df_clean["id_ligne"].iloc[-1]) == len(df_clean)


def test_4a_stats_population_describe_is_consistent():
    # --- RENDU: préparation
    df = load_villes_csv(CSV_PATH)
    df_clean = clean_villes_df(df)

    # --- RENDU: stats
    s = stats_population(df_clean)

    # --- RENDU: clés attendues
    expected = {"count", "mean", "std", "min", "25%", "50%", "75%", "max"}
    assert expected.issubset(set(s.index))

    # --- RENDU: cohérence math
    assert s["count"] == len(df_clean)
    assert s["min"] <= s["50%"] <= s["max"]
