# ======================================================================================
# TESTS UNITAIRES – GEOPANDAS
# ======================================================================================

from pathlib import Path
import geopandas as gpd  # type: ignore

# --- RENDU: import des fonctions métier
from tp2_application_geo_g37 import (
    load_villes_csv,
    clean_villes_df,
    to_geodataframe_villes,
    load_pays_shapefile,
    spatial_join_villes_pays,
    missing_match_count,
    match_rate,
)

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"

CSV_PATH = DATA_DIR / "villes.csv"
SHP_PATH = DATA_DIR / "pays.shp"


def test_4b_to_geodataframe_has_geometry_and_crs():
    # --- RENDU: prépare df_clean minimal
    df = load_villes_csv(CSV_PATH)
    df_clean = clean_villes_df(df)

    # --- RENDU: conversion
    gdf = to_geodataframe_villes(df_clean)

    # --- RENDU: checks
    assert isinstance(gdf, gpd.GeoDataFrame)
    assert "geometry" in gdf.columns
    assert gdf.crs is not None


def test_4b_load_pays_shapefile_ok_geometry_and_crs():
    # --- RENDU: fichiers présents
    assert SHP_PATH.exists(), f"pays.shp introuvable : {SHP_PATH}"

    # --- RENDU: chargement (même si .prj manquant -> fallback CRS)
    gdf_pays = load_pays_shapefile(SHP_PATH)

    assert isinstance(gdf_pays, gpd.GeoDataFrame)
    assert "geometry" in gdf_pays.columns
    assert len(gdf_pays) > 0
    assert gdf_pays.crs is not None


def test_4b_spatial_join_has_index_right_and_not_all_none():
    # --- RENDU: pipeline réel
    df = load_villes_csv(CSV_PATH)
    df_clean = clean_villes_df(df_clean=df) if False else clean_villes_df(df)  # garde simple

    gdf_villes = to_geodataframe_villes(df_clean)
    gdf_pays = load_pays_shapefile(SHP_PATH)

    # --- RENDU: jointure
    gdf_join = spatial_join_villes_pays(gdf_villes, gdf_pays, predicate="intersects")

    # --- RENDU: structure
    assert "index_right" in gdf_join.columns
    assert len(gdf_join) == len(gdf_villes)

    # --- RENDU: qualité (pas tout None)
    none_count = missing_match_count(gdf_join)
    assert none_count < len(gdf_join)

    # --- RENDU: taux de match raisonnable (seuil prudent)
    assert match_rate(gdf_join) > 0.5
