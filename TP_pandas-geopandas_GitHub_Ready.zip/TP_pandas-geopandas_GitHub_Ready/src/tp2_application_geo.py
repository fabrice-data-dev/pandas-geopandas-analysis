# =============================================================================================
#    (MODULE MÉTIER + SCRIPT TP2)
# =============================================================================================

from __future__ import annotations

from pathlib import Path

import pandas as pd  # type: ignore
import geopandas as gpd  # type: ignore
from shapely.geometry import Point  # type: ignore

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm
from matplotlib.ticker import FuncFormatter


# =============================================================================================
# =============================  CONFIG / CHEMINS PROJET ====================================
# =============================================================================================

def get_base_dir() -> Path:
    """
    Retourne le dossier racine du projet :
    - en .py : dossier du fichier
    - en notebook / interactif : dossier courant
    """
    try:
        return Path(__file__).resolve().parent
    except NameError:
        return Path.cwd()


BASE_DIR = get_base_dir()

DATA_DIR = BASE_DIR / "data"
OUTPUT_DIR = BASE_DIR / "outputs"
OUTPUT_DIR.mkdir(exist_ok=True)

CSV_PATH = DATA_DIR / "villes.csv"
SHP_PATH = DATA_DIR / "pays.shp"


# =============================================================================================
# =============================  FONCTIONS MÉTIER (PANDAS) ==================================
# =============================================================================================

def load_villes_csv(csv_path: Path) -> pd.DataFrame:
    """ Charge le CSV des villes dans un DataFrame Pandas."""
    return pd.read_csv(csv_path)


def clean_villes_df(df: pd.DataFrame) -> pd.DataFrame:
    """
    Nettoie les données :
      - supprime les NaN sur population/latitude/longitude
      - filtre population > 0
      - filtre latitude [-90, 90]
      - filtre longitude [-180, 180]
      - ajoute id_ligne (1..n) en première colonne
    """
    df_clean = df.copy()

    # --- RENDU (nettoyage): dropna sur colonnes critiques
    df_clean = df_clean.dropna(subset=["population", "latitude", "longitude"])

    # --- RENDU (filtrage): contraintes population + bornes lat/lon
    df_clean = df_clean[
        (df_clean["population"] > 0)
        & (df_clean["latitude"].between(-90, 90))
        & (df_clean["longitude"].between(-180, 180))
    ].copy()

    # --- RENDU (numérotation): id_ligne = 1..n
    df_clean = df_clean.reset_index(drop=True)
    df_clean.insert(0, "id_ligne", df_clean.index + 1)

    return df_clean


def stats_population(df_clean: pd.DataFrame) -> pd.Series:
    """ Retourne les statistiques descriptives de la population (describe)."""
    return df_clean["population"].describe()


def export_df_clean_csv(df_clean: pd.DataFrame, output_csv: Path) -> None:
    """Exporte le DataFrame nettoyé en CSV (outputs/...)."""
    df_clean.to_csv(output_csv, index=False, encoding="utf-8")


# =============================================================================================
# =============================  FONCTIONS MÉTIER (GEOPANDAS) ================================
# =============================================================================================

def to_geodataframe_villes(df_clean: pd.DataFrame, crs: str = "EPSG:4326") -> gpd.GeoDataFrame:
    """ Convertit df_clean en GeoDataFrame avec Point(lon, lat)."""
    gdf_villes = gpd.GeoDataFrame(
        df_clean.copy(),
        geometry=[Point(xy) for xy in zip(df_clean["longitude"], df_clean["latitude"])],
        crs=crs,
    )
    return gdf_villes


def load_pays_shapefile(shp_path: Path, fallback_crs: str = "EPSG:4326") -> gpd.GeoDataFrame:
    """
      Charge un shapefile des pays.
    - Si CRS absent, on force fallback_crs.
    - Répare les géométries (buffer(0)).
    
    """
    gdf_pays = gpd.read_file(shp_path)

    # --- RENDU (CRS): fallback si absent
    if gdf_pays.crs is None:
        print("\nERREUR: CRS pays manquant -> tentative EPSG:4326 (fallback)")
        gdf_pays = gdf_pays.set_crs(fallback_crs, allow_override=True)

    # --- RENDU (géométrie): réparation polygones invalides
    gdf_pays = gdf_pays.copy()
    gdf_pays["geometry"] = gdf_pays.geometry.buffer(0)

    return gdf_pays


def prefix_pays_columns(gdf_pays: gpd.GeoDataFrame, prefix: str = "pays_") -> gpd.GeoDataFrame:
    """Préfixe les colonnes non-geometry des pays pour éviter les conflits après jointure."""
    cols_rename = {c: f"{prefix}{c}" for c in gdf_pays.columns if c != "geometry"}
    return gdf_pays.rename(columns=cols_rename)


def spatial_join_villes_pays(
    gdf_villes: gpd.GeoDataFrame,
    gdf_pays: gpd.GeoDataFrame,
    predicate: str = "intersects",
) -> gpd.GeoDataFrame:
    """
      Jointure spatiale villes -> pays.
    - Harmonise CRS (villes reprojetées vers CRS des pays)
    - how='left' conserve toutes les villes
    """
    gdf_villes_tmp = gdf_villes
    if gdf_villes_tmp.crs != gdf_pays.crs:
        gdf_villes_tmp = gdf_villes_tmp.to_crs(gdf_pays.crs)

    gdf_join = gpd.sjoin(gdf_villes_tmp, gdf_pays, how="left", predicate=predicate)
    return gdf_join


def detect_country_name_column(gdf_pays: gpd.GeoDataFrame) -> str | None:
    """
    Détecte une colonne texte plausible pour le nom du pays (après préfixage pays_).
    Retourne le nom de colonne ou None si introuvable.
    """
    cols_pays = [c for c in gdf_pays.columns if c.startswith("pays_") and c != "geometry"]
    candidats = [
        "pays_name", "pays_NAME", "pays_ADMIN", "pays_COUNTRY", "pays_SOVEREIGNT",
        "pays_CNTRY_NAME", "pays_NAME_EN", "pays_NAME_FR",
    ]
    col_pays = next((c for c in candidats if c in gdf_pays.columns), None)

    if col_pays is None:
        cols_textes = [c for c in cols_pays if str(gdf_pays[c].dtype) == "object"]
        col_pays = cols_textes[0] if cols_textes else None

    return col_pays


def add_pays_calcule(gdf_join: gpd.GeoDataFrame, gdf_pays: gpd.GeoDataFrame) -> gpd.GeoDataFrame:
    """
    Ajoute une colonne pays_calcule à partir de index_right (résultat sjoin).
    Méthode robuste : mapping index pays -> pays_calcule puis merge.
    """
    col_pays = detect_country_name_column(gdf_pays)

    if col_pays is None:
        print("\nERREUR: Impossible de détecter une colonne nom du pays -> pays_calcule=None")
        gdf_join = gdf_join.copy()
        gdf_join["pays_calcule"] = None
        return gdf_join

    # --- RENDU: colonne retenue
    print(f"\n=== [PAYS] Colonne retenue pour pays_calcule : {col_pays} ===")

    map_pays = gdf_pays[[col_pays]].copy()
    map_pays = map_pays.rename(columns={col_pays: "pays_calcule"})
    map_pays["index_pays"] = map_pays.index

    gdf_join = gdf_join.merge(
        map_pays,
        how="left",
        left_on="index_right",
        right_on="index_pays",
    ).drop(columns=["index_pays"], errors="ignore")

    return gdf_join


def finalize_join_columns(gdf_join: gpd.GeoDataFrame) -> gpd.GeoDataFrame:
    """Garde uniquement les colonnes utiles attendues."""
    colonnes_utiles = [
        "id_ligne", "ville", "pays", "pays_calcule",
        "population", "latitude", "longitude", "geometry"
    ]
    colonnes_utiles = [c for c in colonnes_utiles if c in gdf_join.columns]
    return gdf_join[colonnes_utiles].copy()


def export_join_results(gdf_join: gpd.GeoDataFrame, geojson_path: Path, csv_path: Path) -> None:
    """Exporte la jointure en GeoJSON (avec geometry) et CSV (sans geometry)."""
    gdf_join.to_file(geojson_path, driver="GeoJSON")
    gdf_join.drop(columns="geometry").to_csv(csv_path, index=False, encoding="utf-8")


def missing_match_count(gdf_join: gpd.GeoDataFrame) -> int:
    """Nombre de villes sans pays associé (index_right NaN)."""
    return int(gdf_join["index_right"].isna().sum()) if "index_right" in gdf_join.columns else len(gdf_join)


def match_rate(gdf_join: gpd.GeoDataFrame) -> float:
    """Taux de correspondance (match)."""
    total = len(gdf_join)
    if total == 0:
        return 0.0
    return 1.0 - (missing_match_count(gdf_join) / total)


# =====================================================================================================================
# =============================  VISUALISATION DES DONNES EN CARTOGRAPHIE(EXPORT CARTE) ================================
# =====================================================================================================================

def export_map_villes_population(
    gdf_join: gpd.GeoDataFrame,
    gdf_pays: gpd.GeoDataFrame,
    output_img: Path,
) -> None:
    """
    Génère une carte :
      - frontières pays
      - points villes
      - couleur = population (log)
      - taille = population (clamp 5-95%)
      - export PNG haute résolution
    """
    # --- RENDU: copie de travail
    gdf_map = gdf_join.copy()

    # --- RENDU: population numérique
    gdf_map["population"] = pd.to_numeric(gdf_map.get("population"), errors="coerce")

    # --- RENDU: suppression NaN + géométries vides
    gdf_map = gdf_map.dropna(subset=["population", "geometry"]).copy()

    # --- RENDU: suppression pop <= 0
    gdf_map = gdf_map[gdf_map["population"] > 0].copy()

    # --- RENDU: nombre de villes affichables
    print("\n=== [RENDU] Nombre de villes affichées sur la carte ===")
    print(len(gdf_map))

    # --- RENDU: tailles des points (clamp 5-95%)
    p = gdf_map["population"].to_numpy()
    p_low, p_high = np.percentile(p, [5, 95])
    p_clamped = np.clip(p, p_low, p_high)

    size_min, size_max = 18, 220
    gdf_map["marker_size"] = (
        size_min + (p_clamped - p_low) * (size_max - size_min) / (p_high - p_low + 1e-9)
    )

    print("\n=== [RENDU] Exemple de tailles de points calculées ===")
    print(gdf_map["marker_size"].head())

    # --- RENDU: figure
    fig, ax = plt.subplots(figsize=(14, 8))

    # --- RENDU: pays (fond + frontières)
    gdf_pays.plot(ax=ax, alpha=0.18, linewidth=0.6, edgecolor="black")
    gdf_pays.boundary.plot(ax=ax, linewidth=0.8)

    # --- RENDU: scatter villes
    xs = gdf_map.geometry.x.to_numpy()
    ys = gdf_map.geometry.y.to_numpy()

    sc = ax.scatter(
        xs,
        ys,
        s=gdf_map["marker_size"].to_numpy(),
        c=gdf_map["population"].to_numpy(),
        norm=LogNorm(vmin=gdf_map["population"].min(), vmax=gdf_map["population"].max()),
        alpha=0.78,
    )

    # --- RENDU: colorbar (population)
    cbar = fig.colorbar(sc, ax=ax, fraction=0.03, pad=0.02)
    cbar.set_label("Population (échelle logarithmique)", fontsize=10)

    def format_population(x, pos):
        return f"{int(x):,}".replace(",", " ")

    cbar.formatter = FuncFormatter(format_population)
    cbar.update_ticks()

    # --- RENDU: légende taille (bubble)
    q25, q50, q75 = np.percentile(gdf_map["population"], [25, 50, 75])

    def size_from_pop(x):
        x = np.clip(x, p_low, p_high)
        return size_min + (x - p_low) * (size_max - size_min) / (p_high - p_low + 1e-9)

    handles = [plt.scatter([], [], s=size_from_pop(v), alpha=0.78) for v in (q25, q50, q75)]
    labels = [f"{int(v):,}".replace(",", " ") for v in (q25, q50, q75)]

    legend_size = ax.legend(
        handles,
        labels,
        title="Population (taille des points)",
        loc="lower left",
        frameon=True,
    )
    ax.add_artist(legend_size)

    # --- RENDU: titres / axes / footer
    ax.set_title("Carte des villes selon la population et frontières des pays", fontsize=14)
    ax.set_xlabel("Longitude")
    ax.set_ylabel("Latitude")

    ax.text(
        0.01,
        0.01,
        "Couleur = population (log) | Taille = population (5–95%) | Source : villes.csv + pays.shp",
        transform=ax.transAxes,
        fontsize=9,
    )

    plt.tight_layout()

    # --- RENDU: export image
    plt.savefig(output_img, dpi=300, bbox_inches="tight")
    plt.show()

    print("\n=== [EXPORT] Carte finale générée avec succès ===")
    print("Image :", output_img)


# =============================================================================================
# =============================  MAIN (EXÉCUTION TP COMPLET) =================================
# =============================================================================================

def main() -> None:
    # -------------------------------------------------------------------------
    # CONFIG D'AFFICHAGE PANDAS (console)
    # -------------------------------------------------------------------------
    pd.set_option("display.max_rows", None)
    pd.set_option("display.max_columns", None)
    pd.set_option("display.width", 180)  # --- RENDU: évite affichage cassé

    # =========================================================================
    #  MANIPULATION DES DONNÉES AVEC PANDAS
    # =========================================================================

    # --- RENDU: chargement CSV
    df = load_villes_csv(CSV_PATH)

    print("\n=== Aperçu des données ===")
    print(df.head(100))  # --- RENDU: 100 premières lignes

    print("\n=== Informations sur le DataFrame ===")
    df.info()  # --- RENDU: structure

    print("\n=== Dimensions (lignes, colonnes) ===")
    print(df.shape)  # --- RENDU: dimensions

    print("\n=== Valeurs manquantes par colonne ===")
    print(df.isnull().sum())  # --- RENDU: missing values

    # --- RENDU: nettoyage
    df_clean = clean_villes_df(df)

    print("\n=== Bilan nettoyage ===")
    print(f"Lignes avant nettoyage : {len(df)}")
    print(f"Lignes après nettoyage : {len(df_clean)}")
    print(f"Lignes supprimées      : {len(df) - len(df_clean)}")

    print("\n=== Informations sur le DataFrame nettoyé ===")
    df_clean.info()  # --- RENDU: structure finale

    print("\n=== [FINAL] Données filtrées ===")
    print(df_clean)  # --- RENDU: affichage dataset filtré

    # --- RENDU: statistiques
    s = stats_population(df_clean)
    print("\n=== Statistiques descriptives sur la population (describe) ===")
    print(s)

    print("\n=== Compléments (moyenne, médiane, min, max) ===")
    print("Moyenne  :", df_clean["population"].mean())
    print("Médiane  :", df_clean["population"].median())
    print("Min      :", df_clean["population"].min())
    print("Max      :", df_clean["population"].max())

    # --- RENDU: export CSV filtré
    output_csv_filtre = OUTPUT_DIR / "villes_filtrees.csv"
    export_df_clean_csv(df_clean, output_csv_filtre)

    print("\n=== [EXPORT] Fichier créé avec succès ===")
    print(f"Chemin : {output_csv_filtre}")

    # =========================================================================
    #  ANALYSE GÉOSPATIALE AVEC GEOPANDAS
    # =========================================================================

    # --- RENDU: df_clean -> GeoDataFrame
    gdf_villes = to_geodataframe_villes(df_clean)

    print("\n===  GeoDataFrame Villes (aperçu) ===")
    print(gdf_villes.head())
    print("CRS villes :", gdf_villes.crs)

    # --- RENDU: chargement pays shapefile + sécurisation
    gdf_pays = load_pays_shapefile(SHP_PATH)

    print("\n===  Shapefile Pays (aperçu) ===")
    print(gdf_pays.head())
    print("CRS pays (après fallback si besoin) :", gdf_pays.crs)
    print("Colonnes pays (brut) :", list(gdf_pays.columns))

    # --- RENDU: préfixage colonnes pays
    gdf_pays = prefix_pays_columns(gdf_pays, prefix="pays_")

    print("\n=== [PAYS] Colonnes pays après préfixage (pays_) ===")
    print([c for c in gdf_pays.columns if c != "geometry"][:40])

    # --- RENDU: jointure test rapide
    test_join = spatial_join_villes_pays(gdf_villes, gdf_pays, predicate="intersects")
    test_none = missing_match_count(test_join)

    print("\n=== [TEST] Villes sans pays (avec pays.shp) ===")
    print(test_none, "/", len(test_join))

    # --- RENDU: jointure finale
    gdf_join = spatial_join_villes_pays(gdf_villes, gdf_pays, predicate="intersects")

    nb_sans_pays = missing_match_count(gdf_join)
    print("\n=== Jointure finale : villes sans pays ===")
    print(nb_sans_pays)

    print("\n=== Aperçu jointure finale ===")
    print(gdf_join.head(50))

    # --- RENDU: création pays_calcule
    gdf_join = add_pays_calcule(gdf_join, gdf_pays)

    print("\n=== [RESULTAT] Ville / pays_calcule (aperçu) ===")
    cols_check = [c for c in ["ville", "pays", "pays_calcule"] if c in gdf_join.columns]
    print(gdf_join[cols_check].head(50))

    # --- RENDU: colonnes finales
    gdf_join = finalize_join_columns(gdf_join)

    print("\n=== [FINAL] Données finales (aperçu) ===")
    print(gdf_join.head(100))

    # --- RENDU: export join
    output_geojson = OUTPUT_DIR / "villes_avec_pays.geojson"
    output_join_csv = OUTPUT_DIR / "villes_avec_pays.csv"
    export_join_results(gdf_join, output_geojson, output_join_csv)

    print("\n=== [EXPORT] Fichiers générés ===")
    print("GeoJSON :", output_geojson)
    print("CSV     :", output_join_csv)

    # =========================================================================
    #  VISUALISATION DES DONNÉES (CARTE + EXPORT IMAGE)
    # =========================================================================

    output_img = OUTPUT_DIR / "carte_rapport_final_population.png"
    export_map_villes_population(gdf_join=gdf_join, gdf_pays=gdf_pays, output_img=output_img)


# =============================================================================================
# Garde anti-exécution lors des imports (OBLIGATOIRE pour pytest)
# =============================================================================================
if __name__ == "__main__":
    main()
